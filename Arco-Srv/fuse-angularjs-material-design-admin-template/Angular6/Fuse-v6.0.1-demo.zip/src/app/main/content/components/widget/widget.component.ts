import { Component } from '@angular/core';

@Component({
    selector   : 'fuse-widget-docs',
    templateUrl: './widget.component.html',
    styleUrls  : ['./widget.component.scss']
})
export class FuseWidgetDocsComponent
{
    constructor()
    {

    }
}
