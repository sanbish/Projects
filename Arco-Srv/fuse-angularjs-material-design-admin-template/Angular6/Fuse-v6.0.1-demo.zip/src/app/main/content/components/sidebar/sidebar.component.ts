import { Component } from '@angular/core';

@Component({
    selector   : 'fuse-sidebar-docs',
    templateUrl: './sidebar.component.html',
    styleUrls  : ['./sidebar.component.scss']
})
export class FuseSidebarDocsComponent
{
    constructor()
    {
    }
}
